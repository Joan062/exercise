def avg_num(num1, num2, num3):
    avg = (num1 + num2 + num3)/3
    return avg
print(avg_num)
avg_num(1,6,9)
