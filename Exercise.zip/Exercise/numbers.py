'''def double(nums):
    newArr = 0
    for i in range(len(nums)):
        newArr.append(nums[i]*2)
    return newArr
print(double(nums=[1,2,3]))'''

def double(arr, x, y):
    for i in range(x):
        if(arr[i] == y):
            x = x * 2
        return x
arr = [2, 4, 6]
x = 2
y = len(arr)

print(double(arr, x, y))
