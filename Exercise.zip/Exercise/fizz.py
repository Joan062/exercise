def buzz(max):
    numbers = 0
    for i in range(0, max):
        
        if((i%4 == 0 or i%6 == 0)and (i %4!=0 or i % 6!= 0)):
            numbers.append(i)

        i+= 1
    return numbers
print(buzz(10))