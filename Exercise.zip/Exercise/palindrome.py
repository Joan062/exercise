def palindrom(string):
    return string == string[::-1]
string = "level"
answer = palindrom
if answer:
    print("True")
else:
    print("False")


