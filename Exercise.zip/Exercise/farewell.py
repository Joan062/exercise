def bye(name):
    print("Goodbye", name)
bye("Tim")